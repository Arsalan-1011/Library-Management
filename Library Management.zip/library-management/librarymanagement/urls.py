"""librarymanagement URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf.urls import include
from django.urls import path
from library import views
from django.contrib.auth.views import LoginView,LogoutView



urlpatterns = [
    path('Librarian/', admin.site.urls),
    path('accounts/',include('django.contrib.auth.urls') ),
    path('', views.home_view),

    path('Librarianclick', views.Librarianclick_view),
    path('Memberclick', views.Memberclick_view),


    path('Librariansignup', views.Librariansignup_view),
    path('Membersignup', views.Memberadd_view),
    path('Librarianlogin', LoginView.as_view(template_name='library/Librarianlogin.html')),
    path('Memberlogin', LoginView.as_view(template_name='library/Memberlogin.html')),

    path('logout', LogoutView.as_view(template_name='library/index.html')),
    path('afterlogin', views.afterlogin_view),

    path('addbook', views.addbook_view),
    path('viewbook', views.viewbook_view),
    path('updatemember', views.updateMember_view),
    path('updateprofile', views.updateProfile_view),
    path('deletebook', views.deletebook_view),
    path('issuebook', views.issuebook_view),
    path('viewissuedbook', views.viewissuedbook_view),
    path('returnBook', views.returnBook_view),

    path('viewMember', views.removeMember_view),
    path('viewMember', views.viewMember_view),
    path('viewissuedbookbyMember', views.viewissuedbookbyMember),

    path('aboutus', views.aboutus_view),
    path('contactus', views.contactus_view),

]
