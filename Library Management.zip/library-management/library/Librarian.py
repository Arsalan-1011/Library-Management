from django.contrib import admin
from .models import Book,MemberExtra,IssuedBook
class BookLibrarian(Librarian.ModelLibrarian):
    pass
Librarian.site.register(Book, BookLibrarian)


class MemberExtraLibrarian(Librarian.ModelLibrarian):
    pass
Librarian.site.register(MemberExtra, MemberExtraLibrarian)


class IssuedBookLibrarian(Librarian.ModelLibrarian):
    pass
Librarian.site.register(IssuedBook, IssuedBookLibrarian)
